create view V_EMP_41 as
select id, first_name, salary, dept_id from s_emp where dept_id = 41 with read only
